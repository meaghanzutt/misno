exports.handler = async (event) => {
  try {
    const user = JSON.parse(event.body || "{}").user || {};
    return {
      statusCode: 200,
      body: JSON.stringify({
        app_metadata: {
          roles: ["community"]
        },
        user_metadata: user.user_metadata || {}
      })
    };
  } catch (error) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "Unable to create account metadata." })
    };
  }
};
